//
//  ViewController.swift
//  CurrencyConverter
//
//  Created by Eray Sen on 4.07.2020.
//  Copyright © 2020 Eray Sen. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var cadLabel: UILabel!
    @IBOutlet weak var chfLabel: UILabel!
    @IBOutlet weak var gbpLabel: UILabel!
    @IBOutlet weak var jpyLabel: UILabel!
    @IBOutlet weak var tryLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func getRates(_ sender: Any) {
    // 1. Adım - İstek göndermek - Request & Session - App içerisinden API adresine gitmek aslında
    // 2. Adım - Cevap almak - Response & Data
    // 3. Adım - Cevabı gelen veriyi işlemek - Parsing & Json Serialization işlemi
        
        let url = URL(string: "http://data.fixer.io/api/latest?access_key=b5d9e76d28024bfe75173759d51ec981&format=1" )
        let session = URLSession.shared  //task için session objesini oluşturduk.
        
        //closure'lara istediğimiz isimleri verebiliriz
        let task = session.dataTask(with: url!) { (data, response, error) in
        //kotroller ile başlıyoruz. Öncelikle bir hata varsa eğer başka bişey yapmaya gerek yok tabii ki. Hata varsa ekrana uyarı yazdırıcaz. Bunun için de alert oluşturacağız. Hata mesajı closure’daki error üzerinden geliyor. Sonra da alert’a bir button ekliyoruz.
            
            if error != nil{
                let alert = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: UIAlertController.Style.alert)
                let okButton = UIAlertAction(title: "OK!", style: UIAlertAction.Style.default, handler: nil)
                alert.addAction(okButton)
                self.present(alert, animated: true, completion: nil)
            } else {   // 2. adıma geçiyoruz
                if data != nil{
                      // Url miz http olduğu için info.plist'ten izin veriyoruz. Https olsa gerekmez
                    do{
                    let jsonResponse = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as! Dictionary<String, Any>
                        
                        //Json'ı app'e almak yani yazdırmak için arka plandaki threat'i kullanmalıyım. Ana threat uygulamayı kitleyebilir, kullanıcı o esnada başka birşey yaparsa eğer
                        DispatchQueue.main.async {
                            // 3. adım olarak jsonResponse'u dictionary<String, Any> olarak almalıyım yukarıyı cast ediyorum
                            if let rates = jsonResponse["rates"] as? [String : Any]{//Dict oluşturmanın                                                          diğer yöntemi
                                if let cad = rates["CAD"] as? Double{
                                    self.cadLabel.text = "CAD: \(cad)"
                                }
                                if let chf = rates["CHF"] as? Double{
                                    self.chfLabel.text = "CHF: \(chf)"
                                }
                                if let gbp = rates["GBP"] as? Double{
                                    self.gbpLabel.text = "GBP: \(gbp)"
                                }
                                if let jpy = rates["JPY"] as? Double{
                                    self.jpyLabel.text = "JPY: \(jpy)"
                                }                                
                                if let TRY = rates["TRY"] as? Double{
                                    self.tryLabel.text = "TRY: \(TRY)"
                                }
                            }
                        }
                    
                    }catch{
                        print("error!")
                    }
                }
            }
        }
        task.resume()
        
    }
    
}

